package com.example.sis;

public class Filiere {
    public int id;
    public String name;

    public String times;
    public String center;
    public int hours;
    public String part;
    public String salle;
}
