package com.example.sis;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import okhttp3.ResponseBody;
import retrofit2.Call;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import retrofit2.Callback;
import retrofit2.Response;

public class Fees extends AppCompatActivity {
    private SharedPreferences pref;
    private NetworkUtils networkUtils;
    private User user;

    private WebView fees_wbv;
    private WebView wbv_printer;
    private ArrayList<fees_item> Items ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fees);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        pref = getSharedPreferences("user_details",MODE_PRIVATE);
        user = new User(pref.getString("UserLogin", null ) );

        ActionBar actionBar = this.getSupportActionBar();
        String classTitle = actionBar.getTitle().toString();

        actionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setCustomView(R.layout.custom_action_bar);
        View view = actionBar.getCustomView();
        TextView activity_title = view.findViewById(R.id.activity_title);
        activity_title.setText(classTitle);
        TextView user_id_name = view.findViewById(R.id.user_id_name);
        user_id_name.setText( user.code() + "  |  " + user.ar_name());

        wbv_printer = view.findViewById(R.id.wbv_printer);



        networkUtils = new NetworkUtils();
        APIEndPoint apiEndPoint = networkUtils.getApiEndPoint();
        fees_wbv = findViewById(R.id.fees_wbv);
        fees_wbv.getSettings().setBuiltInZoomControls(true);

        Call<ResponseBody> call = apiEndPoint.Fees("application/json", user.id());
        call.enqueue(new Callback<ResponseBody>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    String html = "";
                    if (response.code() == 200) {
                        Document document = Jsoup.parse(response.body().string());
                        Element p = document.select("body").first();

                        double req = 0;
                        double pai = 0;

                        Gson gson = new Gson();

                        Type collectionType = new TypeToken<ArrayList<fees_item>>(){}.getType();
                        Items = gson.fromJson(p.text(), collectionType);

                        html += "<table class='table_' cellspacing='0' cellpadding='0' >";
                        html += "<thead>";
                        html += "<tr>";
                        html += "<td>Fee Type</td>";
                        html += "<td>Required Amount</td>";
                        html += "<td>Paid Amount</td>";
                        html += "</tr>";
                        html += "</thead>";

                        html += "<tbody>";
                        int i = 0;
                        for( fees_item item : Items ){
                            req += item.required_amount;
                            pai += item.paid_amount;

                            html += "<tr class='cls_"+i+"'>";
                            html += "<td>"+item.type+"</td>";
                            html += "<td>"+item.required_amount+"</td>";
                            html += "<td>"+item.paid_amount+"</td>";
                            html += "</tr>";

                            if(i== 0)
                                i=1;
                            else
                                i=0;

                        }
                        html += "</tbody>";
                        html += "<tfoot>";
                        html += "<tr>";
                        html += "<td colspan='2'>Student Balance</td>";
                        html += "<td>"+ String.format("%.2f", ( req - pai ) )+"</td>";
                        html += "</tr>";
                        html += "</tfoot>";
                        html += "</table>";
                        html +="<style>table td{padding: 10px; } table thead tr td,table tfoot tr td{background: #3465A4; color: #fff; } table tbody tr.cls_0 td{background: #eee; }</style>";

                    } else if (response.code() == 404) {
                        //errorText.setText( "Failed to load data" );
                        html = "<br><h3>No Result ....</h3>";
                    }

                    fees_wbv.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
                    wbv_printer.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.d("onFailure", "MSG " + t.getMessage());
            }
        });
    }

    public void createPdf(View view){

        PrintManager printManager = (PrintManager) this.getSystemService(getBaseContext().PRINT_SERVICE);

        PrintDocumentAdapter printAdapter =
                wbv_printer.createPrintDocumentAdapter("SIS");

        String jobName = getString(R.string.app_name) + "Fees_";

        printManager.print(jobName, printAdapter,
                new PrintAttributes.Builder().build());
    }


    public void onOptionsItemSelected(View v){
        Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
        startActivityForResult(myIntent, 0);
        finish();
    }

    class fees_item{
        public String type;
        public double required_amount;
        public double paid_amount;

        public fees_item(String t, double r, double p){
            type = t;
            required_amount = r;
            paid_amount = p;
        }
    }

}
