package com.example.sis;

public class Cours {
    public int id;
    public String Code;
    public String Name;
    public double Part;
    public double Hours;
    public double TMs;
    public double QZs;
    public double FNL;
    public double TOT;
    public String Grade;
    public double Points;

    public String class_no;
    public String period;
    public String status;
    public String tutor;
    public String hall;
    public String reserved;
    public String max_seat;
    public String class_gender;


    public String from;
    public String extra;
    public String plan_year;
    public String study_year;
    public String study_semester;

}