package com.example.sis;

import android.util.Log;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import static java.lang.Long.parseLong;
import static java.lang.Long.sum;

public class User implements Serializable {

    private String id;
    private String code;
    private String ar_name;
    private String en_name;
    public String email;
    private String civilID;
    public String mobile;
    public String adresse;

    private String programe_ar_name;
    private String programe_en_name;

    public User(){
        super();
    }
    public User(String d){
        super();
        fromString(d);
    }


    public String id(){
        return this.id;
    }

    public String code(){
        return this.code;
    }

    public String ar_name(){
        return this.ar_name;
    }

    public String en_name(){
        return this.en_name;
    }

    public String email(){
        return this.email;
    }

    public String civilID(){
        return this.civilID;
    }

    public String mobile(){
        return this.mobile;
    }

    public String adresse(){
        return this.adresse;
    }


    public String programe_ar_name(){
        return this.programe_ar_name;
    }

    public String programe_en_name(){
        return this.programe_en_name;
    }


    public String toString(){
        return id + "@__@" + code + "@__@" + ar_name + "@__@" + en_name + "@__@" + email + "@__@" + civilID + "@__@" + mobile + "@__@" + adresse + "@__@" + programe_ar_name + "@__@" + programe_en_name;
    }

    public User fromString(String data){

        String[] d = data.split("@__@");

        this.id = d[0];
        this.code = d[1];
        this.ar_name = d[2];
        this.en_name = d[3];
        this.email = d[4];
        this.civilID = d[5];
        this.mobile = d[6];
        this.adresse = d[7];
        this.programe_ar_name = d[8];
        this.programe_en_name = d[9];

        return this;
    }
}
