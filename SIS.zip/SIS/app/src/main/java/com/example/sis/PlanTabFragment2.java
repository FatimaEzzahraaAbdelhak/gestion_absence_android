package com.example.sis;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;

import androidx.fragment.app.Fragment;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PlanTabFragment2 extends Fragment {
    private NetworkUtils networkUtils;
    private APIEndPoint apiEndPoint;
    public PrintManager printManager;
    public User user;

    public View view;
    public LayoutInflater linflater;


    private Spinner spiner_type;
    private Spinner spiner_schools;
    private ArrayList<Cours> courses ;
    private WebView wbv;
    private WebView wbv_printer;

    String selectedType = "All";
    String selectedschool = "";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        linflater = inflater;
        View v = inflater.inflate(R.layout.plan_tab_fragment_2, container, false);

        view = v;


        networkUtils = new NetworkUtils();
        apiEndPoint = networkUtils.getApiEndPoint();
        networkUtils = new NetworkUtils();
        apiEndPoint = networkUtils.getApiEndPoint();
        spiner_type = v.findViewById(R.id.spiner_type);
        spiner_schools = v.findViewById(R.id.spinner_school);
        wbv = v.findViewById(R.id.plan_wbv);
        wbv.getSettings().setBuiltInZoomControls(true);
        wbv_printer = v.findViewById(R.id.wbv_printer2);

//        fetchCours();

        spiner_type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch ( Integer.parseInt(id+"") ){
                    case 0:
                        selectedType = "all";
                        break;
                    case 1:
                        selectedType = "Completed";
                        break;
                    case 2:
                        selectedType = "Registered";
                        break;
                    default:
                        selectedType = "Not Completed";
                        break;
                }
                fetchCours();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        spiner_schools.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedschool = parent.getItemAtPosition(position).toString();
                fetchCours();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        ImageButton print = v.findViewById(R.id.plan_details_print);
        print.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                PrintDocumentAdapter printAdapter =
                        wbv_printer.createPrintDocumentAdapter("SIS");

                String jobName = "Plan_";

                printManager.print(jobName, printAdapter,
                        new PrintAttributes.Builder().build());

            }
        });



        return view;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public void fetchCours(){

        Call<ResponseBody> call = apiEndPoint.Plan_details(
                "application/json",
                user.id(),
                selectedschool,
                selectedType
        );
        call.enqueue(new Callback<ResponseBody>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    String html="";
                    if (response.code() == 200) {
                        Document document = Jsoup.parse(response.body().string());
                        Element data_cours = document.select("p").first();

                        Gson gson = new Gson();

                        Type collectionType = new TypeToken<ArrayList<Cours>>(){}.getType();
                        courses = gson.fromJson(data_cours.text(), collectionType);

                        //html += "<h3>"+selectedschool+"</h3>";
                        html += "<table class='table_' cellspacing='0' cellpadding='0' >";
                        html += "<thead>";
                        html += "<tr>";
                        html += "<td>Course Code</td>";
                        html += "<td>Course Name</td>";
                        html += "<td>Hours</td>";
                        html += "<td>Status</td>";
                        html += "<td></td>";
                        html += "<td>Grade</td>";
                        html += "<td>Extra Course Desc</td>";
                        html += "<td>Plan year</td>";
                        html += "<td>Study year</td>";
                        html += "<td>Study semester</td>";
                        html += "</tr>";
                        html += "</thead>";

                        html += "<tbody>";
                        int i = 0;

                        for( Cours c : courses ){

                            html += "<tr class='cls_"+i+"'>";
                            html += "<td>"+c.Code+"</td>";
                            html += "<td>"+c.Name+"</td>";
                            html += "<td>"+c.Hours+"</td>";
                            html += "<td>"+c.status+"</td>";
                            html += "<td>"+c.from+"</td>";
                            html += "<td>"+c.Grade+"</td>";
                            html += "<td>"+c.extra+"</td>";
                            html += "<td>"+c.plan_year+"</td>";
                            html += "<td>"+c.study_year+"</td>";
                            html += "<td>"+c.study_semester+"</td>";
                            html += "</tr>";

                            if(i== 0)
                                i=1;
                            else
                                i=0;

                        }

                        html += "</tbody>";
                        html += "</table>";
                        html +="<style>table td{padding: 10px; } table thead tr td,table tfoot tr td{background: #3465A4; color: #fff; } table tbody tr.cls_0 td{background: #eee; }</style>";
                    } else if (response.code() == 404) {
                        html = "<br><h3>No Result ....</h3>";
                    }

                    wbv.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);

                    wbv_printer.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.d("onFailure", "MSG " + t.getMessage());
            }
        });
    }

}
