package com.example.sis;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PlanTabFragment1 extends Fragment {
    private NetworkUtils networkUtils;
    public User user;

    public View view;
    public LayoutInflater linflater;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
       // super.onCreateView(inflater, container, savedInstanceState);
        linflater = inflater;
        View v = inflater.inflate(R.layout.plan_tab_fragment_1, container, false);

        view = v;

        networkUtils = new NetworkUtils();
        APIEndPoint apiEndPoint = networkUtils.getApiEndPoint();

        Call<ResponseBody> call = apiEndPoint.Plan("application/json", user.id());
        call.enqueue(new Callback<ResponseBody>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    if (response.code() == 200) {
                        Document document = Jsoup.parse(response.body().string());
                        Element p = document.select("body").first();


                        Gson gson = new Gson();
                        Type collectionType = new TypeToken<ArrayList<plan_item>>(){}.getType();
                        ArrayList<plan_item> items = gson.fromJson(p.text(), collectionType);

                        int tot=0;
                        int ch=0;
                        int rh=0;

                        for (plan_item item:items){
                            tot += item.H_total;
                            ch += item.H_completed;
                            rh += item.H_remaining;
                        }

                        items.add(0,new plan_item("",0,0,0 ));
                        items.add(new plan_item("Total",tot,ch,rh ));


                        final MyCustomAdapter myadpter = new MyCustomAdapter(items);
                        myadpter.notifyDataSetChanged();

                        ListView plan_lstview = view.findViewById(R.id.plan_lstview);
                        plan_lstview.setAdapter(myadpter);

                    } else if (response.code() == 404) {
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                    Log.d("onFailure", "MSG --- " + e.getMessage());
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.d("onFailure", "MSG " + t.getMessage());
            }
        });

        return v;
    }




    class plan_item{
        public String label;
        public int H_total;
        public int H_completed;
        public int H_remaining;

        public plan_item(String l, int t, int c, int r){
            label = l;
            H_total = t;
            H_completed = c;
            H_remaining = r;
        }
    }


    class MyCustomAdapter extends BaseAdapter {
        ArrayList<plan_item> Items = new ArrayList<plan_item>();
        MyCustomAdapter(ArrayList<plan_item> Items) {
            this.Items = Items;
        }
        @Override
        public int getCount() {
            return Items.size();
        }

        @Override
        public String getItem(int position) {
            return Items.get(position).label;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int i, View convertView, ViewGroup viewGroup) {
            //LayoutInflater linflater = (LayoutInflater) view.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View v = convertView;

            v = linflater.inflate(R.layout.plan_item, null);
            Context context = v.getContext();

            TextView t = (TextView) v.findViewById(R.id.plan_label);
            TextView th = (TextView) v.findViewById(R.id.total_hours);
            TextView ch = (TextView) v.findViewById(R.id.completed_hours);
            TextView rh = (TextView) v.findViewById(R.id.remaining_hours);

            if( i == 0 || i == getCount() - 1 ){
                LinearLayout wrap_fees_item = (LinearLayout) v.findViewById(R.id.wrap_plan_item);
                wrap_fees_item.setBackgroundColor( getResources().getColor(R.color.colorPrimary) );
                wrap_fees_item.setPadding(5,5,5,5);

                t.setTextColor( getResources().getColor(R.color.colorWhite) );
                t.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

                th.setTextColor( getResources().getColor(R.color.colorWhite) );
                ch.setTextColor( getResources().getColor(R.color.colorWhite) );
                rh.setTextColor( getResources().getColor(R.color.colorWhite) );

                if( i == getCount() - 1 ){
                    t.setText( "Total" );
                    th.setText( Items.get(i).H_total + "" );
                    ch.setText( Items.get(i).H_completed + "" );
                    rh.setText( Items.get(i).H_remaining + "" );
                }

                return  v;
            }

            t.setText( Items.get(i).label );
            th.setText( Items.get(i).H_total + "" );
            ch.setText( Items.get(i).H_completed + "" );
            rh.setText( Items.get(i).H_remaining + "" );

            return v;
        }
    }
}