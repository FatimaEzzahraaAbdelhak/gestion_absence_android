package com.example.sis;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Grade extends AppCompatActivity {
    private SharedPreferences pref;
    private NetworkUtils networkUtils;
    APIEndPoint apiEndPoint;
    private User user;

    private Spinner spiner_semester;
    private Spinner spinner_years;
    private ArrayList<String> years;
    private ArrayList<Cours> courses ;
    private WebView wbv;
    private WebView wbv_printer;

    String selectedYear = "2019";
    String selectedSeme = "1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grade);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        pref = getSharedPreferences("user_details",MODE_PRIVATE);
        user = new User(pref.getString("UserLogin", null ) );

        ActionBar actionBar = this.getSupportActionBar();
        String classTitle = actionBar.getTitle().toString();

        actionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setCustomView(R.layout.custom_action_bar);
        View view = actionBar.getCustomView();
        TextView activity_title = view.findViewById(R.id.activity_title);
        activity_title.setText(classTitle);
        TextView user_id_name = view.findViewById(R.id.user_id_name);
        user_id_name.setText( user.code() + "  |  " + user.ar_name());

        wbv_printer = view.findViewById(R.id.wbv_printer);



        networkUtils = new NetworkUtils();
        apiEndPoint = networkUtils.getApiEndPoint();
        spiner_semester = findViewById(R.id.spiner_semester);
        spinner_years = findViewById(R.id.spinner_years);
        wbv = findViewById(R.id.wbv);

        wbv.getSettings().setBuiltInZoomControls(true);

        fetchCours();

        spiner_semester.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch ( Integer.parseInt(id+"") ){
                    case 0:
                        selectedSeme = "First";
                        break;
                    case 1:
                        selectedSeme = "Second";
                        break;
                    case 2:
                        selectedSeme = "Summer";
                        break;
                    default:
                        selectedSeme = "First";
                        break;
                }
                fetchCours();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        spinner_years.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedYear = parent.getItemAtPosition(position).toString();
                fetchCours();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    public void fetchCours(){
        Call<ResponseBody> call = apiEndPoint.Grades(
                "application/json",
                user.id(),
                selectedYear,
                selectedSeme
        );
        call.enqueue(new Callback<ResponseBody>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    String html="";
                    if (response.code() == 200) {
                        Document document = Jsoup.parse(response.body().string());
                        Element data_years = document.select("p.years").first();
                        Element data_cours = document.select("p.cours").first();

                        Gson gson = new Gson();

                        Type collectionType = new TypeToken<ArrayList<Cours>>(){}.getType();
                        courses = gson.fromJson(data_cours.text(), collectionType);

                        Type collectionType2 = new TypeToken<ArrayList<String>>(){}.getType();
                        years = gson.fromJson(data_years.text(), collectionType2);

                        if( spinner_years.getAdapter() == null ){
                            ArrayAdapter<String> adapter = new ArrayAdapter<String>(Grade.this,
                                    android.R.layout.simple_spinner_item, years);

                            spinner_years.setAdapter(adapter);
                        }

                        html += "<table class='table_' cellspacing='0' cellpadding='0' >";
                        html += "<thead>";
                        html += "<tr>";
                            html += "<td>Course Code</td>";
                            html += "<td>Course Name</td>";
                            html += "<td>Part</td>";
                            html += "<td>Hours</td>";
                            html += "<td>TMs</td>";
                            html += "<td>QZs</td>";
                            html += "<td>FNL</td>";
                            html += "<td>TOT</td>";
                            html += "<td>Grade</td>";
                            html += "<td>Points</td>";
                        html += "</tr>";
                        html += "</thead>";

                        html += "<tbody>";
                        int i = 0;
                        for( Cours c : courses ){

                            html += "<tr class='cls_"+i+"'>";
                            html += "<td>"+c.Code+"</td>";
                            html += "<td>"+c.Name+"</td>";
                            html += "<td>"+c.Part+"</td>";
                            html += "<td>"+c.Hours+"</td>";
                            html += "<td>"+c.TMs+"</td>";
                            html += "<td>"+c.QZs+"</td>";
                            html += "<td>"+c.FNL+"</td>";
                            html += "<td>"+c.TOT+"</td>";
                            html += "<td>"+c.Grade+"</td>";
                            html += "<td>"+c.Points+"</td>";
                            html += "</tr>";

                            if(i== 0)
                                i=1;
                            else
                                i=0;

                        }
                        html += "</tbody>";
                        html += "<tfoot>";
                        html += "<tr>";
                        html += "<td colspan='3'>Sum of semester hours:</td>";
                        html += "<td>12</td>";
                        html += "<td colspan='2'>Sum of semester point:</td>";
                        html += "<td>36</td>";
                        html += "<td colspan='2'>Semester average:</td>";
                        html += "<td>4</td>";
                        html += "</tr>";
                        html += "<tr>";
                        html += "<td colspan='3'>QHRS:</td>";
                        html += "<td>9</td>";
                        html += "<td colspan='2'>QPTS:</td>";
                        html += "<td>36</td>";
                        html += "<td colspan='2'>GPA:</td>";
                        html += "<td>4</td>";
                        html += "</tr>";
                        html += "</tfoot>";
                        html += "</table>";
                        html +="<style>table td{padding: 10px; } table thead tr td,table tfoot tr td{background: #3465A4; color: #fff; } table tbody tr.cls_0 td{background: #eee; }</style>";
                    } else if (response.code() == 404) {
                        html = "<br><h3>No Result ....</h3>";
                    }


                    wbv.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
                    wbv_printer.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);

                    wbv.zoomOut();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.d("onFailure", "MSG " + t.getMessage());
            }
        });
    }

    public void createPdf(View view){

        PrintManager printManager = (PrintManager) this.getSystemService(getBaseContext().PRINT_SERVICE);

        PrintDocumentAdapter printAdapter =
                wbv_printer.createPrintDocumentAdapter("SIS");

        String jobName = getString(R.string.app_name) + "Grade_";

        printManager.print(jobName, printAdapter,
                new PrintAttributes.Builder().build());
    }

    public void onOptionsItemSelected(View v){
        Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
        startActivityForResult(myIntent, 0);
        finish();
    }
}